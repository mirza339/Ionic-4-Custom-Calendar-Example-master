export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyBxPtPWsaRsFT0pTyMTXMsUXEPmu3RU9Tw",
    authDomain: "ionic-4-custom-calendar.firebaseapp.com",
    databaseURL: "https://ionic-4-custom-calendar.firebaseio.com",
    projectId: "ionic-4-custom-calendar",
    storageBucket: "ionic-4-custom-calendar.appspot.com",
    messagingSenderId: "368654596005",
    appId: "1:368654596005:web:4a992dbd09efa5c7"
  }
};
